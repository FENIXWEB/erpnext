/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.18-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: _ebde57cb5cf2199a
-- ------------------------------------------------------
-- Server version	10.6.18-MariaDB-0ubuntu0.22.04.1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Sequence structure for `access_log_id_seq`
--

DROP SEQUENCE IF EXISTS `access_log_id_seq`;
CREATE SEQUENCE `access_log_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`access_log_id_seq`, 5, 0);

--
-- Sequence structure for `activity_log_id_seq`
--

DROP SEQUENCE IF EXISTS `activity_log_id_seq`;
CREATE SEQUENCE `activity_log_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`activity_log_id_seq`, 338, 0);

--
-- Sequence structure for `bisect_nodes_id_seq`
--

DROP SEQUENCE IF EXISTS `bisect_nodes_id_seq`;
CREATE SEQUENCE `bisect_nodes_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`bisect_nodes_id_seq`, 1, 0);

--
-- Sequence structure for `console_log_id_seq`
--

DROP SEQUENCE IF EXISTS `console_log_id_seq`;
CREATE SEQUENCE `console_log_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`console_log_id_seq`, 1, 0);

--
-- Sequence structure for `crm_note_id_seq`
--

DROP SEQUENCE IF EXISTS `crm_note_id_seq`;
CREATE SEQUENCE `crm_note_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`crm_note_id_seq`, 1, 0);

--
-- Sequence structure for `docshare_id_seq`
--

DROP SEQUENCE IF EXISTS `docshare_id_seq`;
CREATE SEQUENCE `docshare_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`docshare_id_seq`, 2, 0);

--
-- Sequence structure for `document_follow_id_seq`
--

DROP SEQUENCE IF EXISTS `document_follow_id_seq`;
CREATE SEQUENCE `document_follow_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`document_follow_id_seq`, 1, 0);

--
-- Sequence structure for `email_queue_id_seq`
--

DROP SEQUENCE IF EXISTS `email_queue_id_seq`;
CREATE SEQUENCE `email_queue_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`email_queue_id_seq`, 1, 0);

--
-- Sequence structure for `energy_point_log_id_seq`
--

DROP SEQUENCE IF EXISTS `energy_point_log_id_seq`;
CREATE SEQUENCE `energy_point_log_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`energy_point_log_id_seq`, 1, 0);

--
-- Sequence structure for `error_log_id_seq`
--

DROP SEQUENCE IF EXISTS `error_log_id_seq`;
CREATE SEQUENCE `error_log_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`error_log_id_seq`, 1, 0);

--
-- Sequence structure for `event_sync_log_id_seq`
--

DROP SEQUENCE IF EXISTS `event_sync_log_id_seq`;
CREATE SEQUENCE `event_sync_log_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`event_sync_log_id_seq`, 1, 0);

--
-- Sequence structure for `event_update_log_id_seq`
--

DROP SEQUENCE IF EXISTS `event_update_log_id_seq`;
CREATE SEQUENCE `event_update_log_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`event_update_log_id_seq`, 1, 0);

--
-- Sequence structure for `ledger_health_id_seq`
--

DROP SEQUENCE IF EXISTS `ledger_health_id_seq`;
CREATE SEQUENCE `ledger_health_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`ledger_health_id_seq`, 1, 0);

--
-- Sequence structure for `notification_log_id_seq`
--

DROP SEQUENCE IF EXISTS `notification_log_id_seq`;
CREATE SEQUENCE `notification_log_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`notification_log_id_seq`, 1, 0);

--
-- Sequence structure for `prospect_opportunity_id_seq`
--

DROP SEQUENCE IF EXISTS `prospect_opportunity_id_seq`;
CREATE SEQUENCE `prospect_opportunity_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`prospect_opportunity_id_seq`, 1, 0);

--
-- Sequence structure for `pwa_notification_id_seq`
--

DROP SEQUENCE IF EXISTS `pwa_notification_id_seq`;
CREATE SEQUENCE `pwa_notification_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`pwa_notification_id_seq`, 1, 0);

--
-- Sequence structure for `scheduled_job_log_id_seq`
--

DROP SEQUENCE IF EXISTS `scheduled_job_log_id_seq`;
CREATE SEQUENCE `scheduled_job_log_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`scheduled_job_log_id_seq`, 60470, 0);

--
-- Sequence structure for `version_id_seq`
--

DROP SEQUENCE IF EXISTS `version_id_seq`;
CREATE SEQUENCE `version_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`version_id_seq`, 381, 0);

--
-- Sequence structure for `view_log_id_seq`
--

DROP SEQUENCE IF EXISTS `view_log_id_seq`;
CREATE SEQUENCE `view_log_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`view_log_id_seq`, 1, 0);

--
-- Sequence structure for `web_form_list_column_id_seq`
--

DROP SEQUENCE IF EXISTS `web_form_list_column_id_seq`;
CREATE SEQUENCE `web_form_list_column_id_seq` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 nocache nocycle ENGINE=InnoDB;
SELECT SETVAL(`web_form_list_column_id_seq`, 1, 0);

--
-- Table structure for table `__Auth`
--

DROP TABLE IF EXISTS `__Auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `__Auth` (
  `doctype` varchar(140) NOT NULL,
  `name` varchar(255) NOT NULL,
  `fieldname` varchar(140) NOT NULL,
  `password` text NOT NULL,
  `encrypted` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`doctype`,`name`,`fieldname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;
